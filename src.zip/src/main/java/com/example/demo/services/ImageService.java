package com.example.demo.services;

import com.example.demo.models.entities.Image;

public interface ImageService {
    void delete(Image image);
}
