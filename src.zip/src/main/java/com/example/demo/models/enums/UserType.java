package com.example.demo.models.enums;

public enum UserType {
    USER,SHELTER
}
