package com.example.demo.models.enums;

public enum AnimalTypes {
    FISH,DOG,CAT,BIRD,REPTILE
}
