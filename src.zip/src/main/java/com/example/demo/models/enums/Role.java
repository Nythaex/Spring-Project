package com.example.demo.models.enums;

public enum Role {
    ADMIN,USER,SHELTER
}
